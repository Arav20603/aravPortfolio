import playfultime from '../assets/fonts/PlayfulTime.ttf'

export const fonts = {
  playfultime
}