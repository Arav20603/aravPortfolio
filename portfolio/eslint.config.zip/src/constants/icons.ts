import linkedIn from '../assets/icons/linkedin.png';
import linkedIn2 from '../assets/icons/linkedin2.png';
import gitHub from '../assets/icons/github.png';
import gitHub2 from '../assets/icons/github2.png';
import menu from '../assets/icons/hamburger.png';
import paws from '../assets/icons/paws.png';
import x from '../assets/icons/social.png';

export const icons = {
  linkedIn,
  linkedIn2,
  gitHub,
  gitHub2,
  menu,
  paws,
  x
};