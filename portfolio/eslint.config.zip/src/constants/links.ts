export const links = {
  furEverCare: 'https://github.com/Arav20603/FurEverCare',
  fitness: 'https://github.com/Arav20603/fitnessCommunity',
  gitHub: 'https://www.github.com/Arav20603',
  linkedIn: 'https://www.linkedin.com/in/aravind-dakshan-d-ab117a2a3/',
  X: 'https://www.X.com/Syndicate0ne/',
}